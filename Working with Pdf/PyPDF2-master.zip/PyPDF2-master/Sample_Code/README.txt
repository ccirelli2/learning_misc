PyPDF2 Sample Code Folder
-------------------------

This will contain demonstrations of the many features
PyPDF2 is capable of. Example code should make it easy
for users to know how to use all aspects of PyPDF2.



Feel free to add any type of PDF file or sample code, 
either by

	1) sending it via email to PyPDF2@phaseit.net
	2) including it in a pull request on GitHub